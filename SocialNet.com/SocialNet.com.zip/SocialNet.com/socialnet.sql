-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2023 at 08:06 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `socialnet`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `uuid` varchar(30) NOT NULL,
  `user_id` varchar(30) NOT NULL,
  `post_id` varchar(100) NOT NULL,
  `comment` varchar(100) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comment_tags`
--

CREATE TABLE `comment_tags` (
  `comment_id` varchar(30) NOT NULL,
  `tag_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comment_tags`
--

INSERT INTO `comment_tags` (`comment_id`, `tag_id`) VALUES
('d4a54121-06bf-4855-b324-8d8c9d', '31bcd26b-5800-42d9-90af-74db93'),
('d4a54121-06bf-4855-b324-8d8c9d', '31bcd26b-5800-42d9-90af-74db93');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `uuid` varchar(30) NOT NULL,
  `user_id` varchar(30) NOT NULL,
  `post` varchar(250) NOT NULL,
  `post_image` varchar(100) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`uuid`, `user_id`, `post`, `post_image`, `created`) VALUES
('7dec9d8f-5703-4336-a498-1f6a7a', 'e2fd12cgadf2d25xf', 'asduasduhadad\r\n#hariini', 'uploads/', '2023-08-24 04:27:24'),
('8936e4a5-d394-4793-9360-c90c95', 'e2fd12cgadf2d25xf', 'woalah iyonyah', 'uploads/WhatsApp Image 2023-08-23 at 23.26.45.jpeg', '2023-08-24 04:10:04'),
('8d1718a0-5f5f-49f4-aa2b-fb732c', 'e2fd12cgadf2d25xf', 'sudah akanmm ', 'uploads/', '2023-08-24 04:27:07'),
('91b28c9c-c5ba-45bc-90cb-c515b3', 'e2fd12cgadf2d25xf', 'sdsfghjjhjghgdfsdraj', 'uploads/', '2023-08-24 04:52:14');

-- --------------------------------------------------------

--
-- Table structure for table `post_tags`
--

CREATE TABLE `post_tags` (
  `post_id` varchar(30) NOT NULL,
  `tag_id` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `tag_id` varchar(30) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`tag_id`, `name`) VALUES
('31bcd26b-5800-42d9-90af-74db93', '#hariini');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uuid` varchar(30) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `picture` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uuid`, `username`, `password`, `created_at`, `keterangan`, `name`, `picture`) VALUES
('e2fd12cgadf2d25xf', 'greed', '$2a$10$LE3iXhC0YEntXFeuKB.uK.i4xRzqBrfhk5FSpCDXF2ssh7CTz41HS', '2023-08-23 05:14:12', 'Hari ini', 'Kefin', 'uploads/user.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`uuid`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`uuid`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`tag_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uuid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
