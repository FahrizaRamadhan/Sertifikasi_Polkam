<?php


include 'config/database.php';
include 'config/config.php';
require 'library/uuid.php';
require 'library/hashtag.php';


$id = $_GET['id'];

$exec = mysqli_query($koneksi, "SELECT * FROM posts WHERE uuid='" . $id . "'");
$data = mysqli_fetch_array($exec);

if (!empty($_POST)) {

    $post = $_POST['post'];

    if (strlen($post) > 250) {
        header("location:feed.php?pesan=panjang");
        exit();
    } else if (strlen($post) <= 0) {
        header('location:feed.php?pesan=kosong');
        exit();
    }

    $targetFilePath = '';

    if (isset($_FILES['media'])) {
        $file = $_FILES['media'];

        // Informasi tentang file yang diunggah
        $fileName = $file['name'];
        $fileTmpName = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileError = $file['error'];

        // Pindahkan file yang diunggah ke lokasi yang ditentukan
        $targetDirectory = 'uploads/'; // Ganti dengan direktori yang sesuai
        $targetFilePath = $targetDirectory . $fileName;

        if ($fileError === 0) {
            if (move_uploaded_file($fileTmpName, $targetFilePath)) {
                echo "File berhasil diunggah.";
            } else {
                echo "Terjadi kesalahan saat mengunggah file.";
            }
        } else {
            echo "Terjadi kesalahan saat mengunggah file: " . $fileError;
        }
    }
    $post_id = $id;

    $exec = mysqli_query($koneksi, "UPDATE posts SET post='" . $post . "', post_image='" . $targetFilePath . "',created='" . date('Y-m-d H:i:s') . "' WHERE uuid='" . $post_id . "'");
    echo mysqli_error($koneksi);

    $ArrTags = carihastag($post);
    if (count($ArrTags) > 0) {
        for ($i = 0; $i < count($ArrTags); $i++) {
            $tag_id = format_uuidv4();
            echo "count : " . $i . '<br>';
            $exec = mysqli_query($koneksi, 'SELECT * FROM tags WHERE name="' . strtolower($ArrTags[$i]) . '"');

            if (mysqli_num_rows($exec) <= 0) {
                $exec = mysqli_query($koneksi, 'INSERT INTO tags VALUES("' . $tag_id . '","' . strtolower($ArrTags[$i]) . '")');
            } else {
                $data = mysqli_fetch_assoc($exec);
                $tag_id = $data['tag_id'];
            }
            mysqli_query($koneksi, "INSERT INTO post_tags VALUES('" . $post_id . "','" . $tag_id . "')");
        }
    }

    header('location:' . $baseURL . 'feed.php');
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="icon" type="image/x-icon" href="<?= $baseURL ?>assets/img/at_icon-icons.com_50456.png">
    <link href="<?= $baseURL ?>assets/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container-fluid">

    <div class="container py-3">
    <header>
      <div class="d-flex flex-column flex-md-row align-items-center pb-3 mb-4 border-bottom">
        <a href="feed.php" class="d-flex align-items-center text-dark text-decoration-none">
          <span class="fs-4">SocialNet</span>
        </a>

        <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
          <a class="me-3 py-2 text-dark text-decoration-none" href="profile.php">Hal</a>
          <a class="py-2" href="logout.php">Logout</a>
        </nav>
      </div>

    </div>
    <section class="mt-3">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-10">
                    <div class="card">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <textarea name="post" id="post" cols="25" rows="10" placeholder="What do you think?" style="resize: none;" class="form-control"><?= $data[2] ?></textarea>
                            <input type="file" name="media" id="" class="form-control">
                            <button type="submit" class="btn btn-info d-flex mt-2 mb-2">Post</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>


</body>
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
<script src="<?= $baseURL ?>assets/js/bootstrap.min.js"></script>
<script src="<?= $baseURL ?>assets/js/bootstrap.bundle.min.js"></script>
<script src="<?= $baseURL ?>assets/js/sweetalert.js"></script>


</html>