<?php

// mengaktifkan session php
session_start();

// menghubungkan dengan koneksi
include 'config/database.php';

// menangkap data yang dikirim dari form
$username = $_POST['username'];
$password = $_POST['password'];



// // menyeleksi data admin dengan username dan password yang sesuai
$execute = mysqli_query($koneksi, "SELECT * FROM users WHERE username='$username'");


// var_dump($execute);
// // menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($execute);
if ($cek <= 0) {
    header("location:index.php?pesan=not_found");
    exit();
}
$data = mysqli_fetch_assoc($execute);

if (password_verify($password, $data['password'])) {
    $_SESSION['username'] = $username;
    $_SESSION['nama'] = $data['name'];
    $_SESSION['userId'] = $data['uuid'];

    header("location:feed.php");
} else {
    header("location:index.php?pesan=gagal");
}
