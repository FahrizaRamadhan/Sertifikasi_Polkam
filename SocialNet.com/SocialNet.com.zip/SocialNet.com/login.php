<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "database_name";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION["user_id"];

// Mengambil informasi pengguna dari database
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Mengambil postingan dari pengguna dan teman-temannya
$sql_posts = "SELECT * FROM posts WHERE user_id = ? OR user_id IN (SELECT friend_id FROM friends WHERE user_id = ?)";
$stmt_posts = $conn->prepare($sql_posts);
$stmt_posts->bind_param("ii", $user_id, $user_id);
$stmt_posts->execute();
$posts_result = $stmt_posts->get_result();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Social Media</title>
</head>
<body>
    <h2>Welcome, <?php echo $user["username"]; ?>!</h2>
    <a href="logout.php">Logout</a>

    <h3>My Posts and Posts from Friends</h3>
    <?php while ($post = $posts_result->fetch_assoc()) : ?>
        <div>
            <strong><?php echo $user["username"]; ?>:</strong>
            <?php echo $post["content"]; ?>
            <p>Posted on: <?php echo $post["post_date"]; ?></p>
        </div>
    <?php endwhile; ?>

</body>
</html>

<?php
$stmt->close();
$stmt_posts->close();
$conn->close();
?>
