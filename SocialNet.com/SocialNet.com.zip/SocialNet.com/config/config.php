<?php
$baseURL = 'http://socialnet.com/';