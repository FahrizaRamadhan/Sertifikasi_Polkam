<?php
include 'config/database.php';
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Proses pembaruan profil di sini
    $name = $_POST["name"];
    $bio = $_POST["bio"];
    $targetFilePath = '';

    if (isset($_FILES['fileToUpload'])) {
        $file = $_FILES['fileToUpload'];

        // Informasi tentang file yang diunggah
        $fileName = $file['name'];
        $fileTmpName = $file['tmp_name'];
        $fileSize = $file['size'];
        $fileError = $file['error'];

        // Pindahkan file yang diunggah ke lokasi yang ditentukan
        $targetDirectory = 'uploads/'; // Ganti dengan direktori yang sesuai
        $targetFilePath = $targetDirectory . $fileName;

        if ($fileError === 0) {
            if (move_uploaded_file($fileTmpName, $targetFilePath)) {
                echo "File berhasil diunggah.";
            } else {
                echo "Terjadi kesalahan saat mengunggah file.";
            }
        } else {
            echo "Terjadi kesalahan saat mengunggah file: " . $fileError;
        }
    }

    // mysqli_query($koneksi, "UPDATE users SET name='" . $_POST['nama'] . "', keterangan='" . $_POST['bio'] . "', picture='" . $targetFilePath . "' WHERE uuid='" . $_SESSION['userId'] . "'");
    // Lakukan proses penyimpanan ke basis data atau penyimpanan yang sesuai
    // Contoh: $sql = "UPDATE users SET name='$newName', bio='$newBio' WHERE user_id=1";
    $result = mysqli_query($koneksi, "UPDATE users SET name='" . $name . "', keterangan='" . $bio . "', picture='" . $targetFilePath . "' WHERE uuid='" . $_SESSION['userId'] . "'");
    // Redirect kembali ke halaman profil setelah pembaruan
    header("Location: profile.php");
    // exit();
}
