<?php
include 'config/config.php';
include 'config/database.php';

session_start();
if (!isset($_SESSION['username'])) {
  header("location:" . $baseURL . "index.php?pesan=belum_login");
} ?>
<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
  <meta name="generator" content="Hugo 0.104.2">
  <title>Beranda</title>

  <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/pricing/">



  <link href="<?= $baseURL ?>assets/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }

    .b-example-divider {
      height: 3rem;
      background-color: rgba(0, 0, 0, .1);
      border: solid rgba(0, 0, 0, .15);
      border-width: 1px 0;
      box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
    }

    .b-example-vr {
      flex-shrink: 0;
      width: 1.5rem;
      height: 100vh;
    }

    .bi {
      vertical-align: -.125em;
      fill: currentColor;
    }

    .nav-scroller {
      position: relative;
      z-index: 2;
      height: 2.75rem;
      overflow-y: hidden;
    }

    .nav-scroller .nav {
      display: flex;
      flex-wrap: nowrap;
      padding-bottom: 1rem;
      margin-top: -1px;
      overflow-x: auto;
      text-align: center;
      white-space: nowrap;
      -webkit-overflow-scrolling: touch;
    }
  </style>


  <!-- Custom styles for this template -->
  <link href="styles/pricing.css" rel="stylesheet">
</head>

<body>

  <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
    <symbol id="check" viewBox="0 0 16 16">
      <title>Check</title>
      <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z" />
    </symbol>
  </svg>

  <div class="container py-3">
    <header>
      <div class="d-flex flex-column flex-md-row align-items-center pb-3 mb-4 border-bottom">
        <a href="feed.php" class="d-flex align-items-center text-dark text-decoration-none">
          <span class="fs-4">SocialNet</span>
        </a>

        <nav class="d-inline-flex mt-2 mt-md-0 ms-md-auto">
          <a class="me-3 py-2 text-dark text-decoration-none" href="profile.php">Perihal</a>
          <a class="py-2" href="logout.php">Logout</a>
        </nav>
      </div>

    </header>

      <section class="mt-3">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-10">
              <div class="card">
                <?php
                if (isset($_GET['pesan'])) {
                  if ($_GET['pesan'] == "panjang") {
                    echo '<div class="alert alert-danger" role="alert">
                                   Postingan tidak boleh lebih dari 250 karakter!</div>';
                  } else if ($_GET['pesan'] == "kosong") {
                    echo '<div class="alert alert-danger" role="alert">
                                   Caption harus di isi!</div>';
                  }
                }
                ?>

                <form action="posthandler.php" method="POST" enctype="multipart/form-data">
                  <textarea name="post" id="post" cols="25" rows="5" placeholder="Apa yang kamu pikirkan hari ini?" style="resize: none;" class="form-control"></textarea>
                  <input type="file" name="media" id="" class="form-control">
                  <button type="submit" class="btn btn-info d-flex mt-2 mb-1">Post</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="mt-3">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-10">
              <input type="text" name="" id="search" class="form-control" placeholder="Cari dengan tagar">
              <div id="tagssearch">
                <?php
                // $exec = mysqli_query($koneksi, "SELECT * FROM `posts`");
                $exec = mysqli_query($koneksi, "SELECT a.uuid, a.post, a.post_image, b.name, DATE_FORMAT(a.created, '%D %M %Y %H:%i:%s') as `readable` FROM `posts` a JOIN users b ON a.user_id = b.uuid ORDER BY a.created DESC;");
                if (mysqli_num_rows($exec) > 0) {
                  $data = mysqli_fetch_all($exec);
                  foreach ($data as $key => $value) { ?>
                    <div class="card mt-2">
                      <div class="card-header align-items-center">
                        <div class="row">
                          <div class="col-md-6">
                            <h6><?= $value[3] . ', ' . $value[4]  ?> </h6>
                          </div>
                          <div class="col-md-6 text-end">
                            <div class="dropdown">
                              <button class="btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <svg width="12" height="14" fill="currentColor" class="bi bi-three-dots-vertical" viewBox="0 0 16 16">
                                  <path d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                </svg>
                              </button>
                              <ul class="dropdown-menu dropdown-menu-dark bg-dark">
                                <li><a href="<?= $baseURL ?>editpost.php?id=<?= $value[0] ?>" class="dropdown-item">edit</a></li>
                                <!-- <li><a class="dropdown-item text-warning" href="#">report</a></li>
                                                    <li>
                                                        <hr class="dropdown-divider border-top border-secondary">
                                                    </li> -->
                                <li><a class="dropdown-item text-danger del" data-id="<?= $value[0] ?>">delete</a></li>
                              </ul>
                            </div>
                          </div>
                        </div>

                      </div>
                      <div class="card-body">
                        <p id="caption"><?= $value[1] ?></p>
                        <div class="row justify-content-evenly">
                          <?= ($value[2] == 'uploads/' ? '' : ' <div class="col-md-4">
                                            <img src="' . $baseURL . $value[2] . '" alt="" style="max-width:20vw" class="shadow">
                                        </div>') ?>
                        </div>

                      </div>
                      <div class="card-footer">
                        <div class="row">
                          <a class="btn d-flex komen" data-id="<?= $value[0] ?>">Comment <i class="fa fa-comment-o fs-4" aria-hidden="true"></i></a>
                        </div>
                      </div>
                    </div>
                  <?php }
                } else { ?>
                  <div class="card mt-2">
                    <div class="card-body">
                      <p>No post available</p>
                    </div>
                  </div>
                <?php }; ?>
              </div>

            </div>
          </div>
        </div>
      </section>

      <!-- Modal -->
      <div class="modal fade" id="modalkomen" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="staticBackdropLabel">Komentar</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
              <div id="komentar" class="p-3"></div>
              <form action="" id="addcomment">
                <div class="input-group mb-3">
                  <input type="text" class="form-control" placeholder="Tambahkan komentar" name="comment" aria-label="Tambahkan komentar" aria-describedby="basic-addon2">
                  <div class="input-group-append">
                    <span class="input-group-text" id="basic-addon2">
                      <button type="submit" class="kirim btn"><i class="fa fa-paper-plane-o" aria-hidden="true"></i>Post</button>
                    </span>
                  </div>
                  <input type="hidden" name="post_id">
                </div>
              </form>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>

          </div>
        </div>
      </div>

      <div class="modal fade" id="editcoment" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">

              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <form action="" id="comment">
                <div class="form-group mb-3">
                  <label for="caption" class="form-label">Caption</label>
                  <textarea class="form-control" name="comment" id="textcomment" cols="25" rows="10" style="resize: none;"></textarea>
                  <button type="submit" class="btn btn-secondary">Simpan</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
  </div>


  <script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
  <script src="<?= $baseURL ?>assets/js/bootstrap.min.js"></script>
  <script src="<?= $baseURL ?>assets/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= $baseURL ?>assets/dist/js/sweetalert.js"></script>
  <script>
    $('.komen').click(function() {
      let comment_id = $(this).data("id");
      loadkomen(comment_id);
      $('input[name="post_id"]').val(comment_id);
      $('#modalkomen').modal('show');
    })

    function loadkomen(id) {

      $.ajax({
        url: '<?= $baseURL ?>loadcomment.php',
        type: 'POST',
        data: {
          id: id
        },
        success: function(response) {
          $('#komentar').html(response);
        }
      })
    }
    $('#addcomment').submit(function(event) {
      event.preventDefault();
      let FormData = $(this).serialize();

      $.ajax({
        url: '<?= $baseURL ?>addcomment.php',
        type: 'POST',
        data: FormData,
        success: function(data) {
          loadkomen($('input[name="post_id"]').val());
          $('input[name="comment"]').val('');
          console.log(FormData);
        }
      })
    })
    $('.del').on('click', function(event) {
      event.preventDefault();
      let id = $(this).data("id");
      Swal.fire({
        title: 'Apakah Anda Yakin?',
        text: "Postingan akan dihapus permanen!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Ya',
        cancelButtonText: 'Tidak'
      }).then((result) => {
        if (result.isConfirmed) {
          $.ajax({
            url: '<?= $baseURL ?>delpost.php?id=' + id,
            type: "GET",
            success: function(response) {
              console.log(response);
              window.location.reload();
            }
          })
        }
      })
    })

    function editcom(el) {
      $.ajax({
        url: '<?= $baseURL ?>getdata.php?id=' + $(el).data('id'),
        type: 'GET',
        success: function(data) {
          data = JSON.parse(data);
          console.log(data);
          $('form#comment').attr('action', 'updatecomment.php?id=' + $(el).data("id"));
          $('textarea#textcomment').text(data.comment);
        }
      })
      $('#editcoment').modal('show');
    }
    $('.edit').on('click', function(event) {
      let id = $(this).data("id");
    })

    $('form#comment').submit(function(event) {
      event.preventDefault();
      let FormData = $(this).serialize();
      let url = $(this).attr('action');

      $.ajax({
        url: '<?= $baseURL ?>' + url,
        type: 'POST',
        data: FormData,
        success: function(response) {
          loadkomen($('input[name="post_id"]').val());
          $('#editcoment').modal('hide');

        }
      })
    })
    $('#search').keyup(function(event) {
      event.preventDefault();
      let value = $(this).val();
      $.ajax({
        url: '<?= $baseURL ?>search.php?key=#' + value,
        type: "GET",
        success: function(response) {
          $('#tagssearch').html(response);
        }
      })
    })
  </script>
</body>

</html>